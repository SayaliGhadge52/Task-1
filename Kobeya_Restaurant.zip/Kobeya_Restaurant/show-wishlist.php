<!doctype html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>My Wishlist</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <style>
	
	body {
    font-family: "open_sansregular" !important;
}
	
    #cont{
        min-height : 626px;
    }
    </style>
</head>
<body>
    <?php include 'includes/_dbconnect.php';?>
    <?php require 'includes/_nav.php' ?>
   
    
    <div class="container" id="cont">
        <div class="row">
            <!--<div class="alert alert-info mb-0" style="width: -webkit-fill-available;">
              <strong>Info!</strong> online payment are currently disabled so please choose cash on delivery.
            </div>-->
            <div class="col-lg-12 text-center border rounded bg-light my-3">
                <h1>My Wishlist</h1>
            </div>
            <div class="col-lg-12">
                
                    <table class="table text-center table-bordered bg-white text-dark" >
                        <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th class="text-left" scope="col" >Product Name</th>
                                <th scope="col">Price</th>
                                <th scope="col">Created At</th>
								<th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							    
								$userId = $_SESSION['userId'];
								
                                $sql = "SELECT * FROM wishlist JOIN product on product.productId=wishlist.product_id";
                                $result = mysqli_query($conn, $sql);
                        
								if(mysqli_num_rows($result)>0){
									
			
                                while($row = mysqli_fetch_assoc($result)){
                            ?>
								<tr>
								<td><?php echo $row["id"]; ?></td>
								<td class="text-left">
								<a href="viewProduct.php?productid=<?php echo $row["productId"]; ?>"><?php echo $row["productName"]; ?></a>
								</td>
								<td><?php echo $row["productPrice"]; ?></td>
								<td><?php echo $row["added_on"]; ?></td>
								  
								<td>
							      <a href="delete-wishlist.php?product_id=<?php echo $row["product_id"] ?>&userId=<?php echo $_SESSION['userId'] ?>"><i class="fas fa-trash-alt" style="color:red;"></i></a> 
							    </td>
								</tr>
                             <?php
				             }
			                 } else {
				             echo "0 results";
			                 }
			                 ?>
								
                        </tbody>
                    </table>
          
            </div>
           
        </div>
    </div>
                                

	
    <?php require 'includes/_footer.php' ?>
    
   
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
   
</body>
</html>