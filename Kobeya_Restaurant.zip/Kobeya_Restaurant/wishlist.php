<?php 
session_start();	
include 'includes/_dbconnect.php';
 
if(!isset($_SESSION['userId'])){
	header('location:index.php');
} else {
		 $userId = $_SESSION['userId'];
		 $product_id=$_GET['id'];
		 
		 $mysql = "SELECT * FROM `wishlist` WHERE product_id = $product_id AND userId = $userId ";
         $myresult = mysqli_query($conn, $mysql);
		 if(mysqli_num_rows($myresult) == 1 ){
			echo 'product already exist in wishlist.';
			header('location:show-wishlist.php');
			
		 } else {
			$sql = "INSERT INTO `wishlist` (`userId`, `product_id`) VALUES ('$userId', '$product_id')";
	     
		    if(mysqli_query($conn, $sql)){
			 header('location:show-wishlist.php');
		 } 
}
}
?>
