<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Home</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	
	
	
	
	
	<style>
	body {
    font-family: "open_sansregular" !important;
}
	

	
		.showcase-area {
  height: 50vh;
  background: linear-gradient(
      rgba(240, 240, 240, 0.144),
      rgba(255, 255, 255, 0.336)
    ),
    url("img/banner.png");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.showcase-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  font-size: 1.6rem;
}

.main-title {
  text-transform: uppercase;
  margin-top: 1.5em;
}
	
#wrapper {
  overflow-x: hidden;
}

#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -8rem;
  transition: margin 0.25s ease-out;
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
  height: 100%;
}

.list-group-item-light {
    color: #000000;
    background-color: #fefefe;
}

	</style>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  </head>
<body>
  <?php include 'includes/_dbconnect.php';?>
  <?php require 'includes/_nav.php' ?>
  
  <!-- Category container starts here -->
  
  
  

  

  
  
  
  
  <section class="showcase-area" id="showcase">
      <div class="showcase-container">
        <h1 class="main-title" id="home"></h1>
        <p></p>
       
      </div>
    </section>
  

  <div class="container my-3 mb-5">
    <div class="col-lg-2 text-center bg-light -my-3" style="margin:auto;border-bottom: 2px; color:#426047 !important;">     
      <h2 class="text-center">Menu</h2>
    </div>  
	
	<div class="d-flex align-items" id="page-content-wrapper">
	<div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light"><a href="index-Copy.php">Food Categories</a></div>	
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=23">Breakfast</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=24">Appetizer & Soup</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=25">Salad</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=26">Main</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=29">Beverages</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=27">Combo</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=28">Dessert</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=30">Coffee & Tea</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=31">Kids Menu</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=32">Occasion Cakes</a>
                </div>
    </div>
    <div class="row">
      <?php 
        $sql = "SELECT * FROM `product`"; 
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
          $id = $row['productId'];
          $cat = $row['productName'];
          $desc = $row['productDesc'];
		  $productPrice = $row['productPrice'];
          echo '<div class="col-xs-3 col-sm-3 col-md-3">
                  <div class="card" style="width: 18rem;">
                    <img src="img/menu-'.$id. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                    <div class="card-body">
                      <h5 class="card-title"><a style="color:#d87944 !important;" href="viewProductList.php?catid=' . $id . '">' . $cat . '</a></h5>
                      <p class="card-text">' . substr($desc, 0, 20). '... </p>
                      <h5 style="color: #333"><b>AED '.$productPrice.'.00</b></h5>
					  <button class="">Add To Cart</button>
					  <button>Quick View</button>
                    </div>
                  </div>
                </div>';
        }
      ?>
  
  </div>
</div>
 </div>
    <?php require 'includes/_footer.php' ?>
 
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>